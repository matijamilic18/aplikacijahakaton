import 'package:flutter/material.dart';
import 'backend/backend.dart';
import 'backend/api_requests/api_manager.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'flutter_flow/flutter_flow_util.dart';

class FFAppState extends ChangeNotifier {
  static final FFAppState _instance = FFAppState._internal();

  factory FFAppState() {
    return _instance;
  }

  FFAppState._internal() {
    initializePersistedState();
  }

  Future initializePersistedState() async {
    prefs = await SharedPreferences.getInstance();
  }

  void update(VoidCallback callback) {
    callback();
    notifyListeners();
  }

  late SharedPreferences prefs;

  bool _triedLoggingIn = false;
  bool get triedLoggingIn => _triedLoggingIn;
  set triedLoggingIn(bool _value) {
    _triedLoggingIn = _value;
  }

  bool _LogInState = true;
  bool get LogInState => _LogInState;
  set LogInState(bool _value) {
    _LogInState = _value;
  }

  bool _nista = false;
  bool get nista => _nista;
  set nista(bool _value) {
    _nista = _value;
  }

  String _predmet = '';
  String get predmet => _predmet;
  set predmet(String _value) {
    _predmet = _value;
  }

  int _godina = 0;
  int get godina => _godina;
  set godina(int _value) {
    _godina = _value;
  }

  String _oblast = '';
  String get oblast => _oblast;
  set oblast(String _value) {
    _oblast = _value;
  }

  double _brotvorenih = 0.0;
  double get brotvorenih => _brotvorenih;
  set brotvorenih(double _value) {
    _brotvorenih = _value;
  }

  double _brzatvorenih = 0.0;
  double get brzatvorenih => _brzatvorenih;
  set brzatvorenih(double _value) {
    _brzatvorenih = _value;
  }
}

LatLng? _latLngFromString(String? val) {
  if (val == null) {
    return null;
  }
  final split = val.split(',');
  final lat = double.parse(split.first);
  final lng = double.parse(split.last);
  return LatLng(lat, lng);
}
