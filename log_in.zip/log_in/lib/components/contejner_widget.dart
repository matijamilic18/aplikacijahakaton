import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'contejner_model.dart';
export 'contejner_model.dart';

class ContejnerWidget extends StatefulWidget {
  const ContejnerWidget({Key? key}) : super(key: key);

  @override
  _ContejnerWidgetState createState() => _ContejnerWidgetState();
}

class _ContejnerWidgetState extends State<ContejnerWidget> {
  late ContejnerModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => ContejnerModel());
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    context.watch<FFAppState>();

    return Container(
      width: 50.0,
      height: 50.0,
      decoration: BoxDecoration(
        color: FlutterFlowTheme.of(context).secondaryBackground,
        boxShadow: [
          BoxShadow(
            blurRadius: 7.0,
            color: Color(0xFF895FD1),
            offset: Offset(0.0, 0.0),
            spreadRadius: 1.0,
          )
        ],
        shape: BoxShape.circle,
      ),
    );
  }
}
