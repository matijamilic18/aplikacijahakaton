// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

Future<DocumentReference?> gptPraseAct(String giantString) async {
  final CollectionReference testsRef =
      FirebaseFirestore.instance.collection('tests');
  const int brPitanja = 5;
  List<List<String>> matrica =
      List.generate(brPitanja, (_) => List.filled(6, ""));

  int left = 0;
  int right = 0;

  String currentStr = "";

  for (int brPit = 0; brPit < brPitanja; brPit++) {
    while (giantString[left] != 'P' &&
        giantString[left + 1] != 'i' &&
        giantString[left + 2] != 't') {
      left++;
    }
    right = left;
    for (int j = 0; j < 5; j++) {
      while (giantString[right] != '\n') {
        right++;
      }
      right++;
      matrica[brPit][j] = giantString.substring(left, right - 1);
      left = right;
    }
    while ((giantString[left] != 'o' && giantString[left] != 'O') ||
        giantString[left + 1] != 'd') {
      left++;
    }
    right = left;
    while (giantString[right] != '~') {
      right++;
    }
    if (giantString[right - 1] == ' ') {
      matrica[brPit][5] = giantString[right - 2];
    } else {
      matrica[brPit][5] = giantString[right - 1];
    }
  }

  final data1 = {
    'pitanje1': matrica[0][0],
    'odgovor11': matrica[0][1],
    'odgovor12': matrica[0][2],
    'odgovor13': matrica[0][3],
    'odgovor14': matrica[0][4],
    'tacan1': matrica[0][5],
    'pitanje2': matrica[1][0],
    'odgovor21': matrica[1][1],
    'odgovor22': matrica[1][2],
    'odgovor23': matrica[1][3],
    'odgovor24': matrica[1][4],
    'tacan2': matrica[1][5],
    'pitanje3': matrica[2][0],
    'odgovor31': matrica[2][1],
    'odgovor32': matrica[2][2],
    'odgovor33': matrica[2][3],
    'odgovor34': matrica[2][4],
    'tacan3': matrica[2][5],
    'pitanje4': matrica[3][0],
    'odgovor41': matrica[3][1],
    'odgovor42': matrica[3][2],
    'odgovor43': matrica[3][3],
    'odgovor44': matrica[3][4],
    'tacan4': matrica[3][5],
    'pitanje5': matrica[4][0],
    'odgovor51': matrica[4][1],
    'odgovor52': matrica[4][2],
    'odgovor53': matrica[4][3],
    'odgovor54': matrica[4][4],
    'tacan5': matrica[4][5],
    'createdat': FieldValue.serverTimestamp(),
  };

  testsRef.add(data1);

  QuerySnapshot querySnapshot =
      await testsRef.orderBy('createdat', descending: true).limit(1).get();
  if (querySnapshot.size > 0) {
    // Retrieve the most recent document from the query snapshot
    DocumentSnapshot documentSnapshot = querySnapshot.docs[0];

    // Get the document reference from the document snapshot
    DocumentReference documentReference = documentSnapshot.reference;

    return documentReference;
  }
}
