import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyAPbRQAjOEcl22z_MdD6fvg6vDXyAo-Sxs",
            authDomain: "authapp-64690.firebaseapp.com",
            projectId: "authapp-64690",
            storageBucket: "authapp-64690.appspot.com",
            messagingSenderId: "572232021967",
            appId: "1:572232021967:web:2f8f1aca4db6cd12f7c4ba"));
  } else {
    await Firebase.initializeApp();
  }
}
