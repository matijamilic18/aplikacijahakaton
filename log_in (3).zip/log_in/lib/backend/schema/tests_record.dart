import 'dart:async';

import 'index.dart';
import 'serializers.dart';
import 'package:built_value/built_value.dart';

part 'tests_record.g.dart';

abstract class TestsRecord implements Built<TestsRecord, TestsRecordBuilder> {
  static Serializer<TestsRecord> get serializer => _$testsRecordSerializer;

  String? get pitanje1;

  String? get odgovor11;

  String? get odgovor12;

  String? get odgovor13;

  String? get odgovor14;

  String? get tacan1;

  String? get pitanje2;

  String? get odgovor21;

  String? get odgovor22;

  String? get odgovor23;

  String? get odgovor24;

  String? get tacan2;

  String? get pitanje3;

  String? get odgovor31;

  String? get odgovor32;

  String? get odgovor33;

  String? get odgovor34;

  String? get tacan3;

  String? get pitanje4;

  String? get odgovor41;

  String? get odgovor42;

  String? get odgovor43;

  String? get odgovor44;

  String? get tacan4;

  String? get pitanje5;

  String? get odgovor51;

  String? get odgovor52;

  String? get odgovor53;

  String? get odgovor54;

  String? get tacan5;

  DateTime? get createdat;

  int? get brojpoena;

  String? get oblast;

  String? get predmet;

  DocumentReference? get userref;

  @BuiltValueField(wireName: kDocumentReferenceField)
  DocumentReference? get ffRef;
  DocumentReference get reference => ffRef!;

  static void _initializeBuilder(TestsRecordBuilder builder) => builder
    ..pitanje1 = ''
    ..odgovor11 = ''
    ..odgovor12 = ''
    ..odgovor13 = ''
    ..odgovor14 = ''
    ..tacan1 = ''
    ..pitanje2 = ''
    ..odgovor21 = ''
    ..odgovor22 = ''
    ..odgovor23 = ''
    ..odgovor24 = ''
    ..tacan2 = ''
    ..pitanje3 = ''
    ..odgovor31 = ''
    ..odgovor32 = ''
    ..odgovor33 = ''
    ..odgovor34 = ''
    ..tacan3 = ''
    ..pitanje4 = ''
    ..odgovor41 = ''
    ..odgovor42 = ''
    ..odgovor43 = ''
    ..odgovor44 = ''
    ..tacan4 = ''
    ..pitanje5 = ''
    ..odgovor51 = ''
    ..odgovor52 = ''
    ..odgovor53 = ''
    ..odgovor54 = ''
    ..tacan5 = ''
    ..brojpoena = 0
    ..oblast = ''
    ..predmet = '';

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('tests');

  static Stream<TestsRecord> getDocument(DocumentReference ref) => ref
      .snapshots()
      .map((s) => serializers.deserializeWith(serializer, serializedData(s))!);

  static Future<TestsRecord> getDocumentOnce(DocumentReference ref) => ref
      .get()
      .then((s) => serializers.deserializeWith(serializer, serializedData(s))!);

  TestsRecord._();
  factory TestsRecord([void Function(TestsRecordBuilder) updates]) =
      _$TestsRecord;

  static TestsRecord getDocumentFromData(
          Map<String, dynamic> data, DocumentReference reference) =>
      serializers.deserializeWith(serializer,
          {...mapFromFirestore(data), kDocumentReferenceField: reference})!;
}

Map<String, dynamic> createTestsRecordData({
  String? pitanje1,
  String? odgovor11,
  String? odgovor12,
  String? odgovor13,
  String? odgovor14,
  String? tacan1,
  String? pitanje2,
  String? odgovor21,
  String? odgovor22,
  String? odgovor23,
  String? odgovor24,
  String? tacan2,
  String? pitanje3,
  String? odgovor31,
  String? odgovor32,
  String? odgovor33,
  String? odgovor34,
  String? tacan3,
  String? pitanje4,
  String? odgovor41,
  String? odgovor42,
  String? odgovor43,
  String? odgovor44,
  String? tacan4,
  String? pitanje5,
  String? odgovor51,
  String? odgovor52,
  String? odgovor53,
  String? odgovor54,
  String? tacan5,
  DateTime? createdat,
  int? brojpoena,
  String? oblast,
  String? predmet,
  DocumentReference? userref,
}) {
  final firestoreData = serializers.toFirestore(
    TestsRecord.serializer,
    TestsRecord(
      (t) => t
        ..pitanje1 = pitanje1
        ..odgovor11 = odgovor11
        ..odgovor12 = odgovor12
        ..odgovor13 = odgovor13
        ..odgovor14 = odgovor14
        ..tacan1 = tacan1
        ..pitanje2 = pitanje2
        ..odgovor21 = odgovor21
        ..odgovor22 = odgovor22
        ..odgovor23 = odgovor23
        ..odgovor24 = odgovor24
        ..tacan2 = tacan2
        ..pitanje3 = pitanje3
        ..odgovor31 = odgovor31
        ..odgovor32 = odgovor32
        ..odgovor33 = odgovor33
        ..odgovor34 = odgovor34
        ..tacan3 = tacan3
        ..pitanje4 = pitanje4
        ..odgovor41 = odgovor41
        ..odgovor42 = odgovor42
        ..odgovor43 = odgovor43
        ..odgovor44 = odgovor44
        ..tacan4 = tacan4
        ..pitanje5 = pitanje5
        ..odgovor51 = odgovor51
        ..odgovor52 = odgovor52
        ..odgovor53 = odgovor53
        ..odgovor54 = odgovor54
        ..tacan5 = tacan5
        ..createdat = createdat
        ..brojpoena = brojpoena
        ..oblast = oblast
        ..predmet = predmet
        ..userref = userref,
    ),
  );

  return firestoreData;
}
