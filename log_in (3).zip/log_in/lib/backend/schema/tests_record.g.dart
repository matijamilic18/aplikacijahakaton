// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'tests_record.dart';

// **************************************************************************
// BuiltValueGenerator
// **************************************************************************

Serializer<TestsRecord> _$testsRecordSerializer = new _$TestsRecordSerializer();

class _$TestsRecordSerializer implements StructuredSerializer<TestsRecord> {
  @override
  final Iterable<Type> types = const [TestsRecord, _$TestsRecord];
  @override
  final String wireName = 'TestsRecord';

  @override
  Iterable<Object?> serialize(Serializers serializers, TestsRecord object,
      {FullType specifiedType = FullType.unspecified}) {
    final result = <Object?>[];
    Object? value;
    value = object.pitanje1;
    if (value != null) {
      result
        ..add('pitanje1')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.odgovor11;
    if (value != null) {
      result
        ..add('odgovor11')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.odgovor12;
    if (value != null) {
      result
        ..add('odgovor12')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.odgovor13;
    if (value != null) {
      result
        ..add('odgovor13')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.odgovor14;
    if (value != null) {
      result
        ..add('odgovor14')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.tacan1;
    if (value != null) {
      result
        ..add('tacan1')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.pitanje2;
    if (value != null) {
      result
        ..add('pitanje2')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.odgovor21;
    if (value != null) {
      result
        ..add('odgovor21')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.odgovor22;
    if (value != null) {
      result
        ..add('odgovor22')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.odgovor23;
    if (value != null) {
      result
        ..add('odgovor23')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.odgovor24;
    if (value != null) {
      result
        ..add('odgovor24')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.tacan2;
    if (value != null) {
      result
        ..add('tacan2')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.pitanje3;
    if (value != null) {
      result
        ..add('pitanje3')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.odgovor31;
    if (value != null) {
      result
        ..add('odgovor31')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.odgovor32;
    if (value != null) {
      result
        ..add('odgovor32')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.odgovor33;
    if (value != null) {
      result
        ..add('odgovor33')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.odgovor34;
    if (value != null) {
      result
        ..add('odgovor34')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.tacan3;
    if (value != null) {
      result
        ..add('tacan3')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.pitanje4;
    if (value != null) {
      result
        ..add('pitanje4')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.odgovor41;
    if (value != null) {
      result
        ..add('odgovor41')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.odgovor42;
    if (value != null) {
      result
        ..add('odgovor42')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.odgovor43;
    if (value != null) {
      result
        ..add('odgovor43')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.odgovor44;
    if (value != null) {
      result
        ..add('odgovor44')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.tacan4;
    if (value != null) {
      result
        ..add('tacan4')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.pitanje5;
    if (value != null) {
      result
        ..add('pitanje5')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.odgovor51;
    if (value != null) {
      result
        ..add('odgovor51')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.odgovor52;
    if (value != null) {
      result
        ..add('odgovor52')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.odgovor53;
    if (value != null) {
      result
        ..add('odgovor53')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.odgovor54;
    if (value != null) {
      result
        ..add('odgovor54')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.tacan5;
    if (value != null) {
      result
        ..add('tacan5')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.createdat;
    if (value != null) {
      result
        ..add('createdat')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(DateTime)));
    }
    value = object.brojpoena;
    if (value != null) {
      result
        ..add('brojpoena')
        ..add(serializers.serialize(value, specifiedType: const FullType(int)));
    }
    value = object.oblast;
    if (value != null) {
      result
        ..add('oblast')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.predmet;
    if (value != null) {
      result
        ..add('predmet')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.userref;
    if (value != null) {
      result
        ..add('userref')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(
                DocumentReference, const [const FullType.nullable(Object)])));
    }
    value = object.ffRef;
    if (value != null) {
      result
        ..add('Document__Reference__Field')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(
                DocumentReference, const [const FullType.nullable(Object)])));
    }
    return result;
  }

  @override
  TestsRecord deserialize(Serializers serializers, Iterable<Object?> serialized,
      {FullType specifiedType = FullType.unspecified}) {
    final result = new TestsRecordBuilder();

    final iterator = serialized.iterator;
    while (iterator.moveNext()) {
      final key = iterator.current! as String;
      iterator.moveNext();
      final Object? value = iterator.current;
      switch (key) {
        case 'pitanje1':
          result.pitanje1 = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String?;
          break;
        case 'odgovor11':
          result.odgovor11 = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String?;
          break;
        case 'odgovor12':
          result.odgovor12 = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String?;
          break;
        case 'odgovor13':
          result.odgovor13 = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String?;
          break;
        case 'odgovor14':
          result.odgovor14 = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String?;
          break;
        case 'tacan1':
          result.tacan1 = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String?;
          break;
        case 'pitanje2':
          result.pitanje2 = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String?;
          break;
        case 'odgovor21':
          result.odgovor21 = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String?;
          break;
        case 'odgovor22':
          result.odgovor22 = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String?;
          break;
        case 'odgovor23':
          result.odgovor23 = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String?;
          break;
        case 'odgovor24':
          result.odgovor24 = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String?;
          break;
        case 'tacan2':
          result.tacan2 = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String?;
          break;
        case 'pitanje3':
          result.pitanje3 = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String?;
          break;
        case 'odgovor31':
          result.odgovor31 = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String?;
          break;
        case 'odgovor32':
          result.odgovor32 = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String?;
          break;
        case 'odgovor33':
          result.odgovor33 = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String?;
          break;
        case 'odgovor34':
          result.odgovor34 = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String?;
          break;
        case 'tacan3':
          result.tacan3 = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String?;
          break;
        case 'pitanje4':
          result.pitanje4 = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String?;
          break;
        case 'odgovor41':
          result.odgovor41 = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String?;
          break;
        case 'odgovor42':
          result.odgovor42 = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String?;
          break;
        case 'odgovor43':
          result.odgovor43 = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String?;
          break;
        case 'odgovor44':
          result.odgovor44 = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String?;
          break;
        case 'tacan4':
          result.tacan4 = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String?;
          break;
        case 'pitanje5':
          result.pitanje5 = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String?;
          break;
        case 'odgovor51':
          result.odgovor51 = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String?;
          break;
        case 'odgovor52':
          result.odgovor52 = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String?;
          break;
        case 'odgovor53':
          result.odgovor53 = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String?;
          break;
        case 'odgovor54':
          result.odgovor54 = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String?;
          break;
        case 'tacan5':
          result.tacan5 = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String?;
          break;
        case 'createdat':
          result.createdat = serializers.deserialize(value,
              specifiedType: const FullType(DateTime)) as DateTime?;
          break;
        case 'brojpoena':
          result.brojpoena = serializers.deserialize(value,
              specifiedType: const FullType(int)) as int?;
          break;
        case 'oblast':
          result.oblast = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String?;
          break;
        case 'predmet':
          result.predmet = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String?;
          break;
        case 'userref':
          result.userref = serializers.deserialize(value,
              specifiedType: const FullType(DocumentReference, const [
                const FullType.nullable(Object)
              ])) as DocumentReference<Object?>?;
          break;
        case 'Document__Reference__Field':
          result.ffRef = serializers.deserialize(value,
              specifiedType: const FullType(DocumentReference, const [
                const FullType.nullable(Object)
              ])) as DocumentReference<Object?>?;
          break;
      }
    }

    return result.build();
  }
}

class _$TestsRecord extends TestsRecord {
  @override
  final String? pitanje1;
  @override
  final String? odgovor11;
  @override
  final String? odgovor12;
  @override
  final String? odgovor13;
  @override
  final String? odgovor14;
  @override
  final String? tacan1;
  @override
  final String? pitanje2;
  @override
  final String? odgovor21;
  @override
  final String? odgovor22;
  @override
  final String? odgovor23;
  @override
  final String? odgovor24;
  @override
  final String? tacan2;
  @override
  final String? pitanje3;
  @override
  final String? odgovor31;
  @override
  final String? odgovor32;
  @override
  final String? odgovor33;
  @override
  final String? odgovor34;
  @override
  final String? tacan3;
  @override
  final String? pitanje4;
  @override
  final String? odgovor41;
  @override
  final String? odgovor42;
  @override
  final String? odgovor43;
  @override
  final String? odgovor44;
  @override
  final String? tacan4;
  @override
  final String? pitanje5;
  @override
  final String? odgovor51;
  @override
  final String? odgovor52;
  @override
  final String? odgovor53;
  @override
  final String? odgovor54;
  @override
  final String? tacan5;
  @override
  final DateTime? createdat;
  @override
  final int? brojpoena;
  @override
  final String? oblast;
  @override
  final String? predmet;
  @override
  final DocumentReference<Object?>? userref;
  @override
  final DocumentReference<Object?>? ffRef;

  factory _$TestsRecord([void Function(TestsRecordBuilder)? updates]) =>
      (new TestsRecordBuilder()..update(updates))._build();

  _$TestsRecord._(
      {this.pitanje1,
      this.odgovor11,
      this.odgovor12,
      this.odgovor13,
      this.odgovor14,
      this.tacan1,
      this.pitanje2,
      this.odgovor21,
      this.odgovor22,
      this.odgovor23,
      this.odgovor24,
      this.tacan2,
      this.pitanje3,
      this.odgovor31,
      this.odgovor32,
      this.odgovor33,
      this.odgovor34,
      this.tacan3,
      this.pitanje4,
      this.odgovor41,
      this.odgovor42,
      this.odgovor43,
      this.odgovor44,
      this.tacan4,
      this.pitanje5,
      this.odgovor51,
      this.odgovor52,
      this.odgovor53,
      this.odgovor54,
      this.tacan5,
      this.createdat,
      this.brojpoena,
      this.oblast,
      this.predmet,
      this.userref,
      this.ffRef})
      : super._();

  @override
  TestsRecord rebuild(void Function(TestsRecordBuilder) updates) =>
      (toBuilder()..update(updates)).build();

  @override
  TestsRecordBuilder toBuilder() => new TestsRecordBuilder()..replace(this);

  @override
  bool operator ==(Object other) {
    if (identical(other, this)) return true;
    return other is TestsRecord &&
        pitanje1 == other.pitanje1 &&
        odgovor11 == other.odgovor11 &&
        odgovor12 == other.odgovor12 &&
        odgovor13 == other.odgovor13 &&
        odgovor14 == other.odgovor14 &&
        tacan1 == other.tacan1 &&
        pitanje2 == other.pitanje2 &&
        odgovor21 == other.odgovor21 &&
        odgovor22 == other.odgovor22 &&
        odgovor23 == other.odgovor23 &&
        odgovor24 == other.odgovor24 &&
        tacan2 == other.tacan2 &&
        pitanje3 == other.pitanje3 &&
        odgovor31 == other.odgovor31 &&
        odgovor32 == other.odgovor32 &&
        odgovor33 == other.odgovor33 &&
        odgovor34 == other.odgovor34 &&
        tacan3 == other.tacan3 &&
        pitanje4 == other.pitanje4 &&
        odgovor41 == other.odgovor41 &&
        odgovor42 == other.odgovor42 &&
        odgovor43 == other.odgovor43 &&
        odgovor44 == other.odgovor44 &&
        tacan4 == other.tacan4 &&
        pitanje5 == other.pitanje5 &&
        odgovor51 == other.odgovor51 &&
        odgovor52 == other.odgovor52 &&
        odgovor53 == other.odgovor53 &&
        odgovor54 == other.odgovor54 &&
        tacan5 == other.tacan5 &&
        createdat == other.createdat &&
        brojpoena == other.brojpoena &&
        oblast == other.oblast &&
        predmet == other.predmet &&
        userref == other.userref &&
        ffRef == other.ffRef;
  }

  @override
  int get hashCode {
    var _$hash = 0;
    _$hash = $jc(_$hash, pitanje1.hashCode);
    _$hash = $jc(_$hash, odgovor11.hashCode);
    _$hash = $jc(_$hash, odgovor12.hashCode);
    _$hash = $jc(_$hash, odgovor13.hashCode);
    _$hash = $jc(_$hash, odgovor14.hashCode);
    _$hash = $jc(_$hash, tacan1.hashCode);
    _$hash = $jc(_$hash, pitanje2.hashCode);
    _$hash = $jc(_$hash, odgovor21.hashCode);
    _$hash = $jc(_$hash, odgovor22.hashCode);
    _$hash = $jc(_$hash, odgovor23.hashCode);
    _$hash = $jc(_$hash, odgovor24.hashCode);
    _$hash = $jc(_$hash, tacan2.hashCode);
    _$hash = $jc(_$hash, pitanje3.hashCode);
    _$hash = $jc(_$hash, odgovor31.hashCode);
    _$hash = $jc(_$hash, odgovor32.hashCode);
    _$hash = $jc(_$hash, odgovor33.hashCode);
    _$hash = $jc(_$hash, odgovor34.hashCode);
    _$hash = $jc(_$hash, tacan3.hashCode);
    _$hash = $jc(_$hash, pitanje4.hashCode);
    _$hash = $jc(_$hash, odgovor41.hashCode);
    _$hash = $jc(_$hash, odgovor42.hashCode);
    _$hash = $jc(_$hash, odgovor43.hashCode);
    _$hash = $jc(_$hash, odgovor44.hashCode);
    _$hash = $jc(_$hash, tacan4.hashCode);
    _$hash = $jc(_$hash, pitanje5.hashCode);
    _$hash = $jc(_$hash, odgovor51.hashCode);
    _$hash = $jc(_$hash, odgovor52.hashCode);
    _$hash = $jc(_$hash, odgovor53.hashCode);
    _$hash = $jc(_$hash, odgovor54.hashCode);
    _$hash = $jc(_$hash, tacan5.hashCode);
    _$hash = $jc(_$hash, createdat.hashCode);
    _$hash = $jc(_$hash, brojpoena.hashCode);
    _$hash = $jc(_$hash, oblast.hashCode);
    _$hash = $jc(_$hash, predmet.hashCode);
    _$hash = $jc(_$hash, userref.hashCode);
    _$hash = $jc(_$hash, ffRef.hashCode);
    _$hash = $jf(_$hash);
    return _$hash;
  }

  @override
  String toString() {
    return (newBuiltValueToStringHelper(r'TestsRecord')
          ..add('pitanje1', pitanje1)
          ..add('odgovor11', odgovor11)
          ..add('odgovor12', odgovor12)
          ..add('odgovor13', odgovor13)
          ..add('odgovor14', odgovor14)
          ..add('tacan1', tacan1)
          ..add('pitanje2', pitanje2)
          ..add('odgovor21', odgovor21)
          ..add('odgovor22', odgovor22)
          ..add('odgovor23', odgovor23)
          ..add('odgovor24', odgovor24)
          ..add('tacan2', tacan2)
          ..add('pitanje3', pitanje3)
          ..add('odgovor31', odgovor31)
          ..add('odgovor32', odgovor32)
          ..add('odgovor33', odgovor33)
          ..add('odgovor34', odgovor34)
          ..add('tacan3', tacan3)
          ..add('pitanje4', pitanje4)
          ..add('odgovor41', odgovor41)
          ..add('odgovor42', odgovor42)
          ..add('odgovor43', odgovor43)
          ..add('odgovor44', odgovor44)
          ..add('tacan4', tacan4)
          ..add('pitanje5', pitanje5)
          ..add('odgovor51', odgovor51)
          ..add('odgovor52', odgovor52)
          ..add('odgovor53', odgovor53)
          ..add('odgovor54', odgovor54)
          ..add('tacan5', tacan5)
          ..add('createdat', createdat)
          ..add('brojpoena', brojpoena)
          ..add('oblast', oblast)
          ..add('predmet', predmet)
          ..add('userref', userref)
          ..add('ffRef', ffRef))
        .toString();
  }
}

class TestsRecordBuilder implements Builder<TestsRecord, TestsRecordBuilder> {
  _$TestsRecord? _$v;

  String? _pitanje1;
  String? get pitanje1 => _$this._pitanje1;
  set pitanje1(String? pitanje1) => _$this._pitanje1 = pitanje1;

  String? _odgovor11;
  String? get odgovor11 => _$this._odgovor11;
  set odgovor11(String? odgovor11) => _$this._odgovor11 = odgovor11;

  String? _odgovor12;
  String? get odgovor12 => _$this._odgovor12;
  set odgovor12(String? odgovor12) => _$this._odgovor12 = odgovor12;

  String? _odgovor13;
  String? get odgovor13 => _$this._odgovor13;
  set odgovor13(String? odgovor13) => _$this._odgovor13 = odgovor13;

  String? _odgovor14;
  String? get odgovor14 => _$this._odgovor14;
  set odgovor14(String? odgovor14) => _$this._odgovor14 = odgovor14;

  String? _tacan1;
  String? get tacan1 => _$this._tacan1;
  set tacan1(String? tacan1) => _$this._tacan1 = tacan1;

  String? _pitanje2;
  String? get pitanje2 => _$this._pitanje2;
  set pitanje2(String? pitanje2) => _$this._pitanje2 = pitanje2;

  String? _odgovor21;
  String? get odgovor21 => _$this._odgovor21;
  set odgovor21(String? odgovor21) => _$this._odgovor21 = odgovor21;

  String? _odgovor22;
  String? get odgovor22 => _$this._odgovor22;
  set odgovor22(String? odgovor22) => _$this._odgovor22 = odgovor22;

  String? _odgovor23;
  String? get odgovor23 => _$this._odgovor23;
  set odgovor23(String? odgovor23) => _$this._odgovor23 = odgovor23;

  String? _odgovor24;
  String? get odgovor24 => _$this._odgovor24;
  set odgovor24(String? odgovor24) => _$this._odgovor24 = odgovor24;

  String? _tacan2;
  String? get tacan2 => _$this._tacan2;
  set tacan2(String? tacan2) => _$this._tacan2 = tacan2;

  String? _pitanje3;
  String? get pitanje3 => _$this._pitanje3;
  set pitanje3(String? pitanje3) => _$this._pitanje3 = pitanje3;

  String? _odgovor31;
  String? get odgovor31 => _$this._odgovor31;
  set odgovor31(String? odgovor31) => _$this._odgovor31 = odgovor31;

  String? _odgovor32;
  String? get odgovor32 => _$this._odgovor32;
  set odgovor32(String? odgovor32) => _$this._odgovor32 = odgovor32;

  String? _odgovor33;
  String? get odgovor33 => _$this._odgovor33;
  set odgovor33(String? odgovor33) => _$this._odgovor33 = odgovor33;

  String? _odgovor34;
  String? get odgovor34 => _$this._odgovor34;
  set odgovor34(String? odgovor34) => _$this._odgovor34 = odgovor34;

  String? _tacan3;
  String? get tacan3 => _$this._tacan3;
  set tacan3(String? tacan3) => _$this._tacan3 = tacan3;

  String? _pitanje4;
  String? get pitanje4 => _$this._pitanje4;
  set pitanje4(String? pitanje4) => _$this._pitanje4 = pitanje4;

  String? _odgovor41;
  String? get odgovor41 => _$this._odgovor41;
  set odgovor41(String? odgovor41) => _$this._odgovor41 = odgovor41;

  String? _odgovor42;
  String? get odgovor42 => _$this._odgovor42;
  set odgovor42(String? odgovor42) => _$this._odgovor42 = odgovor42;

  String? _odgovor43;
  String? get odgovor43 => _$this._odgovor43;
  set odgovor43(String? odgovor43) => _$this._odgovor43 = odgovor43;

  String? _odgovor44;
  String? get odgovor44 => _$this._odgovor44;
  set odgovor44(String? odgovor44) => _$this._odgovor44 = odgovor44;

  String? _tacan4;
  String? get tacan4 => _$this._tacan4;
  set tacan4(String? tacan4) => _$this._tacan4 = tacan4;

  String? _pitanje5;
  String? get pitanje5 => _$this._pitanje5;
  set pitanje5(String? pitanje5) => _$this._pitanje5 = pitanje5;

  String? _odgovor51;
  String? get odgovor51 => _$this._odgovor51;
  set odgovor51(String? odgovor51) => _$this._odgovor51 = odgovor51;

  String? _odgovor52;
  String? get odgovor52 => _$this._odgovor52;
  set odgovor52(String? odgovor52) => _$this._odgovor52 = odgovor52;

  String? _odgovor53;
  String? get odgovor53 => _$this._odgovor53;
  set odgovor53(String? odgovor53) => _$this._odgovor53 = odgovor53;

  String? _odgovor54;
  String? get odgovor54 => _$this._odgovor54;
  set odgovor54(String? odgovor54) => _$this._odgovor54 = odgovor54;

  String? _tacan5;
  String? get tacan5 => _$this._tacan5;
  set tacan5(String? tacan5) => _$this._tacan5 = tacan5;

  DateTime? _createdat;
  DateTime? get createdat => _$this._createdat;
  set createdat(DateTime? createdat) => _$this._createdat = createdat;

  int? _brojpoena;
  int? get brojpoena => _$this._brojpoena;
  set brojpoena(int? brojpoena) => _$this._brojpoena = brojpoena;

  String? _oblast;
  String? get oblast => _$this._oblast;
  set oblast(String? oblast) => _$this._oblast = oblast;

  String? _predmet;
  String? get predmet => _$this._predmet;
  set predmet(String? predmet) => _$this._predmet = predmet;

  DocumentReference<Object?>? _userref;
  DocumentReference<Object?>? get userref => _$this._userref;
  set userref(DocumentReference<Object?>? userref) => _$this._userref = userref;

  DocumentReference<Object?>? _ffRef;
  DocumentReference<Object?>? get ffRef => _$this._ffRef;
  set ffRef(DocumentReference<Object?>? ffRef) => _$this._ffRef = ffRef;

  TestsRecordBuilder() {
    TestsRecord._initializeBuilder(this);
  }

  TestsRecordBuilder get _$this {
    final $v = _$v;
    if ($v != null) {
      _pitanje1 = $v.pitanje1;
      _odgovor11 = $v.odgovor11;
      _odgovor12 = $v.odgovor12;
      _odgovor13 = $v.odgovor13;
      _odgovor14 = $v.odgovor14;
      _tacan1 = $v.tacan1;
      _pitanje2 = $v.pitanje2;
      _odgovor21 = $v.odgovor21;
      _odgovor22 = $v.odgovor22;
      _odgovor23 = $v.odgovor23;
      _odgovor24 = $v.odgovor24;
      _tacan2 = $v.tacan2;
      _pitanje3 = $v.pitanje3;
      _odgovor31 = $v.odgovor31;
      _odgovor32 = $v.odgovor32;
      _odgovor33 = $v.odgovor33;
      _odgovor34 = $v.odgovor34;
      _tacan3 = $v.tacan3;
      _pitanje4 = $v.pitanje4;
      _odgovor41 = $v.odgovor41;
      _odgovor42 = $v.odgovor42;
      _odgovor43 = $v.odgovor43;
      _odgovor44 = $v.odgovor44;
      _tacan4 = $v.tacan4;
      _pitanje5 = $v.pitanje5;
      _odgovor51 = $v.odgovor51;
      _odgovor52 = $v.odgovor52;
      _odgovor53 = $v.odgovor53;
      _odgovor54 = $v.odgovor54;
      _tacan5 = $v.tacan5;
      _createdat = $v.createdat;
      _brojpoena = $v.brojpoena;
      _oblast = $v.oblast;
      _predmet = $v.predmet;
      _userref = $v.userref;
      _ffRef = $v.ffRef;
      _$v = null;
    }
    return this;
  }

  @override
  void replace(TestsRecord other) {
    ArgumentError.checkNotNull(other, 'other');
    _$v = other as _$TestsRecord;
  }

  @override
  void update(void Function(TestsRecordBuilder)? updates) {
    if (updates != null) updates(this);
  }

  @override
  TestsRecord build() => _build();

  _$TestsRecord _build() {
    final _$result = _$v ??
        new _$TestsRecord._(
            pitanje1: pitanje1,
            odgovor11: odgovor11,
            odgovor12: odgovor12,
            odgovor13: odgovor13,
            odgovor14: odgovor14,
            tacan1: tacan1,
            pitanje2: pitanje2,
            odgovor21: odgovor21,
            odgovor22: odgovor22,
            odgovor23: odgovor23,
            odgovor24: odgovor24,
            tacan2: tacan2,
            pitanje3: pitanje3,
            odgovor31: odgovor31,
            odgovor32: odgovor32,
            odgovor33: odgovor33,
            odgovor34: odgovor34,
            tacan3: tacan3,
            pitanje4: pitanje4,
            odgovor41: odgovor41,
            odgovor42: odgovor42,
            odgovor43: odgovor43,
            odgovor44: odgovor44,
            tacan4: tacan4,
            pitanje5: pitanje5,
            odgovor51: odgovor51,
            odgovor52: odgovor52,
            odgovor53: odgovor53,
            odgovor54: odgovor54,
            tacan5: tacan5,
            createdat: createdat,
            brojpoena: brojpoena,
            oblast: oblast,
            predmet: predmet,
            userref: userref,
            ffRef: ffRef);
    replace(_$result);
    return _$result;
  }
}

// ignore_for_file: deprecated_member_use_from_same_package,type=lint
