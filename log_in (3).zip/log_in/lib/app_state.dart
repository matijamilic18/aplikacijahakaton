import 'package:flutter/material.dart';
import 'backend/backend.dart';
import 'backend/api_requests/api_manager.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'flutter_flow/flutter_flow_util.dart';

class FFAppState extends ChangeNotifier {
  static final FFAppState _instance = FFAppState._internal();

  factory FFAppState() {
    return _instance;
  }

  FFAppState._internal() {
    initializePersistedState();
  }

  Future initializePersistedState() async {
    prefs = await SharedPreferences.getInstance();
    _currentDocument =
        prefs.getString('ff_currentDocument')?.ref ?? _currentDocument;
  }

  void update(VoidCallback callback) {
    callback();
    notifyListeners();
  }

  late SharedPreferences prefs;

  bool _triedLoggingIn = false;
  bool get triedLoggingIn => _triedLoggingIn;
  set triedLoggingIn(bool _value) {
    _triedLoggingIn = _value;
  }

  bool _LogInState = true;
  bool get LogInState => _LogInState;
  set LogInState(bool _value) {
    _LogInState = _value;
  }

  bool _nista = false;
  bool get nista => _nista;
  set nista(bool _value) {
    _nista = _value;
  }

  String _predmet = '';
  String get predmet => _predmet;
  set predmet(String _value) {
    _predmet = _value;
  }

  int _godina = 0;
  int get godina => _godina;
  set godina(int _value) {
    _godina = _value;
  }

  String _oblast = '';
  String get oblast => _oblast;
  set oblast(String _value) {
    _oblast = _value;
  }

  double _brotvorenih = 0.0;
  double get brotvorenih => _brotvorenih;
  set brotvorenih(double _value) {
    _brotvorenih = _value;
  }

  double _brzatvorenih = 0.0;
  double get brzatvorenih => _brzatvorenih;
  set brzatvorenih(double _value) {
    _brzatvorenih = _value;
  }

  DocumentReference? _currentDocument;
  DocumentReference? get currentDocument => _currentDocument;
  set currentDocument(DocumentReference? _value) {
    _currentDocument = _value;
    _value != null
        ? prefs.setString('ff_currentDocument', _value.path)
        : prefs.remove('ff_currentDocument');
  }

  bool _tacan1 = false;
  bool get tacan1 => _tacan1;
  set tacan1(bool _value) {
    _tacan1 = _value;
  }

  bool _tacan2 = false;
  bool get tacan2 => _tacan2;
  set tacan2(bool _value) {
    _tacan2 = _value;
  }

  bool _tacan3 = false;
  bool get tacan3 => _tacan3;
  set tacan3(bool _value) {
    _tacan3 = _value;
  }

  bool _tacan4 = false;
  bool get tacan4 => _tacan4;
  set tacan4(bool _value) {
    _tacan4 = _value;
  }

  bool _tacan5 = false;
  bool get tacan5 => _tacan5;
  set tacan5(bool _value) {
    _tacan5 = _value;
  }

  int _poeni = 0;
  int get poeni => _poeni;
  set poeni(int _value) {
    _poeni = _value;
  }

  bool _hommeeee = false;
  bool get hommeeee => _hommeeee;
  set hommeeee(bool _value) {
    _hommeeee = _value;
  }
}

LatLng? _latLngFromString(String? val) {
  if (val == null) {
    return null;
  }
  final split = val.split(',');
  final lat = double.parse(split.first);
  final lng = double.parse(split.last);
  return LatLng(lat, lng);
}
