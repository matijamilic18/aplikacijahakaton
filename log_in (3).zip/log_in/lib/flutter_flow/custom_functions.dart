import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:timeago/timeago.dart' as timeago;
import 'lat_lng.dart';
import 'place.dart';
import '../backend/backend.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../../auth/auth_util.dart';

String? pravljenjeprompta(
  String pre,
  String obl,
) {
  String? prompt = "Napravite školski test za ";
  prompt += pre;
  prompt += " na temu ";
  prompt += obl;
  prompt +=
      ", sastavljen od 5 zatvorenih pitanja sa 4 ponudjena odgovora. Molimo vas da izaberete temeljne i dublje nivoe pitanja kako biste testirali dublje razumevanje gradiva. Ispred svakog pitanja navedite string 'Pitanje'. Nakon pitanja napisite tacan odgovor. Svako pitanje i odgovor je odvojen novim redom. Format odgovora: Pitanje: PITANJA I PONUĐENI ODGOVORI (neka budu obelezeni malim slovima a, b, c i d), pa novi red pa Odgovor: MALO SLOVO TAČNOG ODGOVORA I ~";

  return prompt;
}

String stringPars(String giantString) {
  CollectionReference testsRef = FirebaseFirestore.instance.collection('tests');
  const int brPitanja = 5;
  List<List<String>> matrica =
      List.generate(brPitanja, (_) => List.filled(6, ""));

  int left = 0;
  int right = 0;

  String currentStr = "";

  for (int brPit = 0; brPit < brPitanja; brPit++) {
    while (giantString[left] != 'P' &&
        giantString[left + 1] != 'i' &&
        giantString[left + 2] != 't') {
      left++;
    }
    right = left;
    for (int j = 0; j < 5; j++) {
      while (giantString[right] != '\n') {
        right++;
      }
      right++;
      matrica[brPit][j] = giantString.substring(left, right - 1);
      left = right;
    }
    while ((giantString[left] != 'o' && giantString[left] != 'O') ||
        giantString[left + 1] != 'd') {
      left++;
    }
    right = left;
    while (giantString[right] != '~') {
      right++;
    }
    if (giantString[right - 1] == ' ') {
      matrica[brPit][5] = giantString[right - 2];
    } else {
      matrica[brPit][5] = giantString[right - 1];
    }
  }

  final data1 = {
    'pitanje1': matrica[0][0],
    'odgovor11': matrica[0][1],
    'odgovor12': matrica[0][2],
    'odgovor13': matrica[0][3],
    'odgovor14': matrica[0][4],
    'tacan1': matrica[0][5],
    'pitanje2': matrica[1][0],
    'odgovor21': matrica[1][1],
    'odgovor22': matrica[1][2],
    'odgovor23': matrica[1][3],
    'odgovor24': matrica[1][4],
    'tacan2': matrica[1][5],
    'pitanje3': matrica[2][0],
    'odgovor31': matrica[2][1],
    'odgovor32': matrica[2][2],
    'odgovor33': matrica[2][3],
    'odgovor34': matrica[2][4],
    'tacan3': matrica[2][5],
    'pitanje4': matrica[3][0],
    'odgovor41': matrica[3][1],
    'odgovor42': matrica[3][2],
    'odgovor43': matrica[3][3],
    'odgovor44': matrica[3][4],
    'tacan4': matrica[3][5],
    'pitanje5': matrica[4][0],
    'odgovor51': matrica[4][1],
    'odgovor52': matrica[4][2],
    'odgovor53': matrica[4][3],
    'odgovor54': matrica[4][4],
    'tacan5': matrica[4][5]
  };

  testsRef.add(data1);
  return "";
}
